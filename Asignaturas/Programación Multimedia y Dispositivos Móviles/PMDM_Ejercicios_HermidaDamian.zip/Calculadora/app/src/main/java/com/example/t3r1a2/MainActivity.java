/**
 * 2.DAM
 * PMDM
 * Ejercicio 3.1.2 (Calculadora)
 */


package com.example.t3r1a2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}