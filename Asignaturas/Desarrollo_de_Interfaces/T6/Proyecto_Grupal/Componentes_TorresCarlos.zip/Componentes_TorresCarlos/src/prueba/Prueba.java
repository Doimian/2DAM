/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prueba;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.LongProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleLongProperty;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.util.Callback;
import javafx.util.StringConverter;
import temporizador.Temporizador;

/**
 * FXML Controller class
 *
 * @author Usuario
 */
public class Prueba extends AnchorPane {

    @FXML
    private DatePicker fEntrada;
    @FXML
    private DatePicker fSalida;

    //Posibles formatos
    private final String pattern1 = "dd-MM-yy";
    private final String pattern2 = "dd-MM-yyyy";
    private String pattern;

    //Otros
    private BooleanProperty formato;
    private LongProperty totalDias;

    public Prueba() {
        //Inicializamos el formato
        formato = new SimpleBooleanProperty(true);
        totalDias = new SimpleLongProperty(0);
        //Cargar la vista para el FXML
        FXMLLoader fxmlLoader = new FXMLLoader(
                getClass().getResource("pruebaFXML.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        //Escoge como fecha de entrada la fecha del sistema por defecto.
        fEntrada.setValue(LocalDate.now());

        //Impide que se seleccionen fechas de entrada anteriores a la fecha del sistema
        fechaPosteriorSistema();

        //Impide que se seleccionen fechas de salida anteriores a la fecha de inicio
        fechaPosteriorInicial();

        //Evento para comprobar si se ha cambiado el valor de la fEntrada
        fEntrada.setOnAction((ActionEvent arg0) -> {
            if (fSalida.getValue() != null) {
                setTotalDias();
                if (getTotalDias() < 1) {
                    fSalida.setValue(null);
                }
                fireEvent(arg0);
            }
        });

        //Evento para comprobar si se ha cambiado el valor de la fEntrada
        fSalida.setOnAction((ActionEvent arg0) -> {
            if (fSalida.getValue() != null) {
                setTotalDias();
                fireEvent(arg0);
            }

        });

    }

    /*Introducimos el formato y a su vez llama a cambioFormato para que se modifique*/
    public final void setFormato(final boolean format) {
        formato.set(format);
        cambioFormato();
    }

    /*Obtenemos el formato*/
    public final Boolean getFormato() {
        return formato.get();
    }

    /*Obtenemos el booleanProperty del formato*/
    public final BooleanProperty formatoProperty() {
        return formato;
    }

    /*Cambia el formato en el que se visualiza la fecha, dependiendo de "formato"*/
    public final void cambioFormato() {
        if (getFormato()) {
            pattern = pattern2;
        } else {
            pattern = pattern1;
        }

        StringConverter converter = new StringConverter<LocalDate>() {
            DateTimeFormatter dateFormatter
                    = DateTimeFormatter.ofPattern(pattern);

            @Override
            public String toString(LocalDate date) {
                if (date != null) {
                    return dateFormatter.format(date);
                } else {
                    return "";
                }
            }

            @Override
            public LocalDate fromString(String string) {
                if (string != null && !string.isEmpty()) {
                    return LocalDate.parse(string, dateFormatter);
                } else {
                    return null;
                }
            }
        };
        fEntrada.setConverter(converter);
        fEntrada.setPromptText(pattern.toLowerCase());
        fSalida.setConverter(converter);
        fSalida.setPromptText(pattern.toLowerCase());
    }

    /*Impide que se seleccionen fechas de entrada anteriores a la fecha del sistema*/
    public void fechaPosteriorSistema() {
        final Callback<DatePicker, DateCell> dayCellFactory
                = new Callback<DatePicker, DateCell>() {
            @Override
            public DateCell call(final DatePicker datePicker) {
                return new DateCell() {
                    @Override
                    public void updateItem(LocalDate item, boolean empty) {
                        super.updateItem(item, empty);

                        if (item.isBefore(LocalDate.now())) {
                            setDisable(true);
                            setStyle("-fx-background-color: #ffc0cb;");

                        }
                    }
                };
            }
        };
        fEntrada.setDayCellFactory(dayCellFactory);
    }

    /*Impide que se seleccionen fechas de salida anteriores a la fecha de inicio*/
    public void fechaPosteriorInicial() {
        final Callback<DatePicker, DateCell> dayCellFactory2
                = new Callback<DatePicker, DateCell>() {
            @Override
            public DateCell call(final DatePicker datePicker) {
                return new DateCell() {
                    @Override
                    public void updateItem(LocalDate item, boolean empty) {
                        super.updateItem(item, empty);

                        if (item.isBefore(fEntrada.getValue().plusDays(1))) {
                            setDisable(true);
                            setStyle("-fx-background-color: #ffc0cb;");
                        }
                    }
                };
            }
        };
        fSalida.setDayCellFactory(dayCellFactory2);
    }

    /*Introduce el numero de dias */
    public void setTotalDias() {
        final long dias = ChronoUnit.DAYS.between(
                fEntrada.getValue(), fSalida.getValue());
        totalDias.set(dias);
    }

    /*Obtiene el numero de dias*/
    public final long getTotalDias() {
        return totalDias.get();
    }

    /*Obtrenemos el longProperty del numero de dias*/
    public final LongProperty totalDiasProperty() {
        return totalDias;
    }

    /*Evento para que muestre el Tooltip*/
    @FXML
    private void entraRaton(MouseEvent event) {
        if (fSalida.getValue() != null) {
            setTotalDias();
            fSalida.setTooltip(new Tooltip("Días entre entrada y salida: " + getTotalDias()));
        }

    }

    public LocalDate getFEntrada() {
        return fEntrada.getValue();
    }

    public LocalDate getFSalida() {
        return fSalida.getValue();
    }

    /*Proporciona a que se pueda utilizar la acción "onAction" por parte de la app que utilice el control*/
    public final ObjectProperty<EventHandler<ActionEvent>> onActionProperty() {
        return onAction;
    }

    /*Añade la acción onAction, y pone el valor que se le añade*/
    public final void setOnAction(EventHandler<ActionEvent> value) {
        onActionProperty().set(value);
    }

    /*Obtiene el valor del onAction*/
    public final EventHandler<ActionEvent> getOnAction() {
        return onActionProperty().get();
    }

    /*Manejador de evento para cuando se active el evento onAction, señalamos como actua*/
    private ObjectProperty<EventHandler<ActionEvent>> onAction = new ObjectPropertyBase<EventHandler<ActionEvent>>() {
        @Override
        protected void invalidated() {
            setEventHandler(ActionEvent.ACTION, get());
        }

        @Override
        public Object getBean() {
            return Prueba.this;
        }

        @Override
        public String getName() {
            return "onAction";
        }
    };

}
