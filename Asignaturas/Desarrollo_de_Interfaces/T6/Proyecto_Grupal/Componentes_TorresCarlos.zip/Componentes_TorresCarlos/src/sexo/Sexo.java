/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sexo;

import java.io.File;
import java.io.IOException;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author Carlos Torres Liñán
 */
public class Sexo extends AnchorPane{

    @FXML
    private AnchorPane AnchorPane;
    @FXML
    private RadioButton rbFemenino;
    @FXML
    private ToggleGroup tgsex;
    @FXML
    private RadioButton rbMasculino;
    @FXML
    private ImageView ivImagen;

    private StringProperty sex;
    
    public Sexo(){
        this("f");
    }
    
    public Sexo(String sex){
        this.sex = new SimpleStringProperty(sex);
        
        //Cargamos la vista para el FXML
        FXMLLoader fxmlLoader = new FXMLLoader(
                getClass().getResource("Sexo.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
    }

    @FXML
    private void seleccionFemenino(ActionEvent event) {
        ivImagen.setImage(new Image(new File("src/sexo-femenino.jpg").toURI().toString()));
    }

    @FXML
    private void seleccionMasculino(ActionEvent event) {
        ivImagen.setImage(new Image(new File("src/sexo-masculino.jpg").toURI().toString()));
    }
    
    
}
