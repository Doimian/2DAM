create table provincia
(
    codigo char(2) not null,
    nombre varchar(20) not null,
    constraint codigo_provincia_pk primary key(codigo)
);

insert into provincia values ('XX','Default');
insert into provincia values('HU','Huelva');
insert into provincia values('CA','Cádiz');
insert into provincia values('MA','Málaga');
insert into provincia values('SE','Sévilla');
insert into provincia values('JA','Jaén');
insert into provincia values('AL','Almería');
insert into provincia values('GR','Granada');
insert into provincia values('CO','Córdoba');
