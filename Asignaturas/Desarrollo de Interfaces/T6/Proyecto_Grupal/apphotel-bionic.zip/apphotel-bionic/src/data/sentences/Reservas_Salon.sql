create table reservas_salon
(
    cod int not null generated always as identity,
    cliente varchar(15) not null,
    tipo char(1) not null, /*B = Banquete - J = Jornada - C = Congreso*/ 
    num_personas int not null,
    tipo_cocina varchar(25),
    habitaciones boolean,
    cant_habitaciones int,
    dias_habitaciones int,
    fecha date not null,
    constraint codigo_reservasSalon_pk primary key(cod),
    constraint salon_cliente_fk foreign key(cliente) references cliente(dni)
);