create table cliente
(
    dni varchar(15), /* No ponemos char(9) por si es un dni estranjero */
    nombre varchar(50) not null,
    direccion varchar(70) not null,
    localidad varchar(20),
    cod_provincia char(2) not null,
    telefono char(9),
    constraint dni_cliente_pk primary key (dni),
    constraint prov_cliente_fk foreign key (cod_provincia) references provincia(codigo)
);

insert into cliente values('11122233A','Pepito Pi','Calle pio pio 3','Guaro','MA', '665677887');
insert into cliente values('12345678B','Juan Jarillo','Calle de abajo','Mundo','GR','612312312');
insert into cliente values('87654321C','Marta Martinez','Calle de arriba','Pueblito Bueno','CA','678654634');
