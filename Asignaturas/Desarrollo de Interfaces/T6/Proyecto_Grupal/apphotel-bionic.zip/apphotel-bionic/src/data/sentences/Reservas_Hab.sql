
create table reservas_hab
(
    cod int not null generated always as identity,
    cliente varchar(15) not null,
    fecha_inicio date not null,
    fecha_final date not null,
    cant_hab int not null,
    tipo varchar(30) not null,
    regimen varchar(15) not null,
    fumador boolean,
    constraint codigo_reservasHab_pk primary key(cod),
    constraint hab_cliente_fk foreign key (cliente) references cliente(dni)
);