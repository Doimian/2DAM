package data.entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

//Consultas
@Entity
@Table(name = "RESERVAS_HAB")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ReservasHab.findAll", query = "SELECT r FROM ReservasHab r"),
    @NamedQuery(name = "ReservasHab.findByCod", query = "SELECT r FROM ReservasHab r WHERE r.cod = :cod"),
    @NamedQuery(name = "ReservasHab.findByFechaInicio", query = "SELECT r FROM ReservasHab r WHERE r.fechaInicio = :fechaInicio"),
    @NamedQuery(name = "ReservasHab.findByFechaFinal", query = "SELECT r FROM ReservasHab r WHERE r.fechaFinal = :fechaFinal"),
    @NamedQuery(name = "ReservasHab.findByCantHab", query = "SELECT r FROM ReservasHab r WHERE r.cantHab = :cantHab"),
    @NamedQuery(name = "ReservasHab.findByTipo", query = "SELECT r FROM ReservasHab r WHERE r.tipo = :tipo"),
    @NamedQuery(name = "ReservasHab.findByRegimen", query = "SELECT r FROM ReservasHab r WHERE r.regimen = :regimen"),
    @NamedQuery(name = "ReservasHab.findByFumador", query = "SELECT r FROM ReservasHab r WHERE r.fumador = :fumador")})
public class ReservasHab implements Serializable {

    private static final long serialVersionUID = 1L;
    //Columnas
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "COD")
    private Integer cod;
    @Column(name = "FECHA_INICIO")
    @Temporal(TemporalType.DATE)
    private Date fechaInicio;
    @Column(name = "FECHA_FINAL")
    @Temporal(TemporalType.DATE)
    private Date fechaFinal;
    @Column(name = "CANT_HAB")
    private Integer cantHab;
    @Column(name = "TIPO")
    private String tipo;
    @Column(name = "REGIMEN")
    private String regimen;
    @Column(name = "FUMADOR")
    private Boolean fumador;
    @Column(name = "CLIENTE")
    private String cliente;

    //Getters y Setters
    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getCliente() {
        return cliente;
    }

    public ReservasHab() {
    }

    public ReservasHab(Integer cod) {
        this.cod = cod;
    }

    public Integer getCod() {
        return cod;
    }

    public void setCod(Integer cod) {
        this.cod = cod;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFinal() {
        return fechaFinal;
    }

    public void setFechaFinal(Date fechaFinal) {
        this.fechaFinal = fechaFinal;
    }

    public Integer getCantHab() {
        return cantHab;
    }

    public void setCantHab(Integer cantHab) {
        this.cantHab = cantHab;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getRegimen() {
        return regimen;
    }

    public void setRegimen(String regimen) {
        this.regimen = regimen;
    }

    public Boolean getFumador() {
        return fumador;
    }

    public void setFumador(Boolean fumador) {
        this.fumador = fumador;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cod != null ? cod.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof ReservasHab)) {
            return false;
        }
        ReservasHab other = (ReservasHab) object;
        if ((this.cod == null && other.cod != null) || (this.cod != null && !this.cod.equals(other.cod))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "data.entities.ReservasHab[ cod=" + cod + " ]";
    }

}
