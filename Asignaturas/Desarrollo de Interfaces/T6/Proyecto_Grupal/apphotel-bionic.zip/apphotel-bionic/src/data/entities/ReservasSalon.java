package data.entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

//Consultas
@Entity
@Table(name = "RESERVAS_SALON")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ReservasSalon.findAll", query = "SELECT r FROM ReservasSalon r"),
    @NamedQuery(name = "ReservasSalon.findByCod", query = "SELECT r FROM ReservasSalon r WHERE r.cod = :cod"),
    @NamedQuery(name = "ReservasSalon.findByCliente", query = "SELECT r FROM ReservasSalon r WHERE r.cliente = :cliente"),
    @NamedQuery(name = "ReservasSalon.findByTipo", query = "SELECT r FROM ReservasSalon r WHERE r.tipo = :tipo"),
    @NamedQuery(name = "ReservasSalon.findByNumPersonas", query = "SELECT r FROM ReservasSalon r WHERE r.numPersonas = :numPersonas"),
    @NamedQuery(name = "ReservasSalon.findByTipoCocina", query = "SELECT r FROM ReservasSalon r WHERE r.tipoCocina = :tipoCocina"),
    @NamedQuery(name = "ReservasSalon.findByHabitaciones", query = "SELECT r FROM ReservasSalon r WHERE r.habitaciones = :habitaciones"),
    @NamedQuery(name = "ReservasSalon.findByCantHabitaciones", query = "SELECT r FROM ReservasSalon r WHERE r.cantHabitaciones = :cantHabitaciones"),
    @NamedQuery(name = "ReservasSalon.findByDiasHabitaciones", query = "SELECT r FROM ReservasSalon r WHERE r.diasHabitaciones = :diasHabitaciones"),
    @NamedQuery(name = "ReservasSalon.findByFecha", query = "SELECT r FROM ReservasSalon r WHERE r.fecha = :fecha")})
public class ReservasSalon implements Serializable {

    private static final long serialVersionUID = 1L;
    //Columnas
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "COD")
    private Integer cod;
    @Basic(optional = false)
    @Column(name = "CLIENTE")
    private String cliente;
    @Column(name = "TIPO")
    private Character tipo;
    @Column(name = "NUM_PERSONAS")
    private Integer numPersonas;
    @Column(name = "TIPO_COCINA")
    private String tipoCocina;
    @Column(name = "HABITACIONES")
    private Boolean habitaciones;
    @Column(name = "CANT_HABITACIONES")
    private Integer cantHabitaciones;
    @Column(name = "DIAS_HABITACIONES")
    private Integer diasHabitaciones;
    @Column(name = "FECHA")
    @Temporal(TemporalType.DATE)
    private Date fecha;

    public ReservasSalon() {
    }

    //Getters y Setters
    public ReservasSalon(Integer cod) {
        this.cod = cod;
    }

    public ReservasSalon(Integer cod, String cliente) {
        this.cod = cod;
        this.cliente = cliente;
    }

    public Integer getCod() {
        return cod;
    }

    public void setCod(Integer cod) {
        this.cod = cod;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public Character getTipo() {
        return tipo;
    }

    public void setTipo(Character tipo) {
        this.tipo = tipo;
    }

    public Integer getNumPersonas() {
        return numPersonas;
    }

    public void setNumPersonas(Integer numPersonas) {
        this.numPersonas = numPersonas;
    }

    public String getTipoCocina() {
        return tipoCocina;
    }

    public void setTipoCocina(String tipoCocina) {
        this.tipoCocina = tipoCocina;
    }

    public Boolean getHabitaciones() {
        return habitaciones;
    }

    public void setHabitaciones(Boolean habitaciones) {
        this.habitaciones = habitaciones;
    }

    public Integer getCantHabitaciones() {
        return cantHabitaciones;
    }

    public void setCantHabitaciones(Integer cantHabitaciones) {
        this.cantHabitaciones = cantHabitaciones;
    }

    public Integer getDiasHabitaciones() {
        return diasHabitaciones;
    }

    public void setDiasHabitaciones(Integer diasHabitaciones) {
        this.diasHabitaciones = diasHabitaciones;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cod != null ? cod.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ReservasSalon)) {
            return false;
        }
        ReservasSalon other = (ReservasSalon) object;
        if ((this.cod == null && other.cod != null) || (this.cod != null && !this.cod.equals(other.cod))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "data.entities.ReservasSalon[ cod=" + cod + " ]";
    }

}
