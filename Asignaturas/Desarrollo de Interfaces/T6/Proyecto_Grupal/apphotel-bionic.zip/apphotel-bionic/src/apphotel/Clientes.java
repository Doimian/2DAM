package apphotel;

import data.entities.Cliente;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javax.persistence.EntityManager;
import javax.persistence.Query;

public class Clientes implements Initializable {

    //Inicializamos elementos FXML
    @FXML
    private TableView<Cliente> tableViewClientes;

    @FXML
    private TableColumn<Cliente, String> columnDniClientes;
    @FXML
    private TableColumn<Cliente, String> columnNombreClientes;
    @FXML
    private TableColumn<Cliente, String> columnDireccionClientes;
    @FXML
    private TableColumn<Cliente, String> columnLocalidadClientes;
    @FXML
    private TableColumn<Cliente, String> columnTelefonoClientes;
    @FXML
    private TableColumn<Cliente, String> columnCodProvinciaClientes;

    //Creamos EntityManager
    private EntityManager entityManager;

    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Le damos los valores a cada una de las celdas de la tabla
        columnDniClientes.setCellValueFactory(new PropertyValueFactory<>("dni"));
        columnNombreClientes.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        columnDireccionClientes.setCellValueFactory(new PropertyValueFactory<>("direccion"));
        columnLocalidadClientes.setCellValueFactory(new PropertyValueFactory<>("localidad"));
        columnTelefonoClientes.setCellValueFactory(new PropertyValueFactory<>("telefono"));
        columnCodProvinciaClientes.setCellValueFactory(cellData
                -> {
            SimpleStringProperty property = new SimpleStringProperty();
            if (cellData.getValue().getCodProvincia() != null) {
                property.setValue(cellData.getValue().getCodProvincia().getNombre());
            }

            return property;
        });

    }

    //Método para cargar los clientes en la tabla
    public void cargarTodosClientes() {
        //Buscamos todos los clientes
        Query queryClientesFindAll = entityManager.createNamedQuery("Cliente.findAll");
        List<Cliente> listClientes = queryClientesFindAll.getResultList();
        //Introducimos los clientes en la tabla
        tableViewClientes.setItems(FXCollections.observableArrayList(listClientes));
    }

}
