package apphotel;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.SQLException;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.image.ImageView;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/*
*    @author Equipo Bionic
*
 */
public class AppHotel extends Application {

    //Creamos los objetos EntityManagerFactory y EntityManager
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("AppHotelPU");
    EntityManager em = emf.createEntityManager();

    //Inicializamos los elementos de FXML
    @FXML
    private Menu menuClientes;
    @FXML
    private Menu menuReservas;
    @FXML
    private MenuItem menuitemHabitaciones;
    @FXML
    private MenuItem menuitemSalon;
    @FXML
    private Menu menuAyuda;
    @FXML
    private ImageView imageViewPrincipal;

    @Override
    public void start(Stage primaryStage) throws IOException {
        // Cargamos la interfaz de AppHotel
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Resources/fxml/AppHotel.fxml"));
        Parent root = fxmlLoader.load();

        // La añadimos a la escena
        Scene scene = new Scene(root);

        //Cerramos EntityManager
        em.close();
        emf.close();
        //Creamos la conexión a la base de datos
        try {
            DriverManager.getConnection("jdbc:derby:BDAgenda;shutdown=true");
        } catch (SQLException ex) {
        }

        // Añadimos la escena al stage y la hacemos visible
        primaryStage.setTitle("AppHotel");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    // METODO PARA ACCEDER A LOS DATOS DE LOS CLIENTES
    @FXML
    private void onClickClientes(ActionEvent event) throws IOException {
        // Cargamos la clase de los clientes                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Resources/fxml/Clientes.fxml"));
        Parent clientes = fxmlLoader.load();

        emf = Persistence.createEntityManagerFactory("AppHotelPU");
        em = emf.createEntityManager();
        // Cogemos el controlador de Clientes
        Clientes clientesController = (Clientes) fxmlLoader.getController();
        // Pasamos el objeto em a la clase controladora
        clientesController.setEntityManager(em);
        // Cargamos todos los clientes existentes hasta el momento
        clientesController.cargarTodosClientes();

        // Creamos la escena y lo añadimos
        Scene sceneClientes = new Scene(clientes);

        // Creamos un nuevo stage para una nueva pestaña, en la que se mostraran los clientes
        Stage stageClientes = new Stage();
        stageClientes.setResizable(false);
        // Hacemos la ventana de tipo modal respecto a la aplicación
        stageClientes.initModality(Modality.APPLICATION_MODAL);

        // Añadimos la escena al stage y la hacemos visible
        stageClientes.setTitle("Clientes");
        stageClientes.setScene(sceneClientes);
        stageClientes.setResizable(false);
        stageClientes.show();
    }

    // METODO PARA ACCEDER A LA PESTAÑA DE RESERVA DE HABITACIONES
    @FXML
    private void onClickHabitaciones(ActionEvent event) throws IOException {
        // Cargamos la clase de habitaciones
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Resources/fxml/Habitaciones.fxml"));
        Parent habitaciones = fxmlLoader.load();

        // Crea la escena y lo añade
        Scene sceneHabitaciones = new Scene(habitaciones);

        // Creamos un stage para una nueva pestaña, en la que estará el formulario para reservar la habitación
        Stage stageHabitaciones = new Stage();
        // Hacemos la ventana de tipo modal respecto a la aplicación
        stageHabitaciones.initModality(Modality.APPLICATION_MODAL);

        // Añadimos la escena al stage y la hacemos visible
        stageHabitaciones.setTitle("Reserva de habitaciones");
        stageHabitaciones.setScene(sceneHabitaciones);
        stageHabitaciones.show();
    }

    // MÉTODO PARA ACCEDER A LA PESTAÑA DE RESERVA DE SALON HABANA
    @FXML
    private void onClickSalon(ActionEvent event) throws IOException {
        // Cargamos la clase de salón Habana
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Resources/fxml/Habana.fxml"));
        Parent salon = fxmlLoader.load();

        // Creamos la escena y la añadimos a la primaryStage
        Scene sceneSalon = new Scene(salon);

        // Creamos un stage para una nueva pestaña, en la que estará el formulario para reservar el salón Habana
        Stage stageSalon = new Stage();
        // Hacemos la ventana de tipo modal respecto a la aplicación
        stageSalon.initModality(Modality.APPLICATION_MODAL);

        // Añadimos la escena al stage y la hacemos visible
        stageSalon.setTitle("Reserva de Salón Habana");
        stageSalon.setScene(sceneSalon);
        stageSalon.show();
    }

    // MÉTODO PARA ACCEDER A LA PESTAÑA DE AYUDA
    @FXML
    private void onClickAyuda() throws IOException {
        // Cargamos la clase de ayuda
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Resources/fxml/Ayuda.fxml"));
        Parent ayuda = fxmlLoader.load();

        // Creamos una escena y la añadimos a la primaryStage
        Scene sceneAyuda = new Scene(ayuda);

        // Creamos un stage para una nueva pestaña, en la que estará la ayuda para el usuario
        Stage stageAyuda = new Stage();
        stageAyuda.setResizable(false);
        // Hacemos la ventana de tipo modal respecto a la aplicación
        stageAyuda.initModality(Modality.APPLICATION_MODAL);

        // Añadimos la escena a la stage y la hacemos visible.
        stageAyuda.setTitle("Sobre nosotros: ");

        stageAyuda.setScene(sceneAyuda);
        stageAyuda.setResizable(false);
        stageAyuda.show();
    }

}
