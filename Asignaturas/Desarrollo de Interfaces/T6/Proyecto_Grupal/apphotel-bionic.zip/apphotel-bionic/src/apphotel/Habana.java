package apphotel;

import data.entities.Cliente;
import data.entities.Provincia;
import data.entities.ReservasSalon;
import java.net.URL;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import javafx.scene.input.MouseEvent;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import temporizador.Temporizador;

/*
*    @author Equipo Bionic
*
 */
public class Habana implements Initializable {

    //Inicializamos los elementos FXML
    @FXML
    private TextField tfDNI;
    @FXML
    private TextField tfNombre;
    @FXML
    private TextField tfDireccion;
    @FXML
    private TextField tfTelefono;
    @FXML
    private RadioButton rbBanquete;
    @FXML
    private TextField tfNumeroPersonas;
    @FXML
    private ComboBox<String> cbTipoCocina;
    @FXML
    private RadioButton rbJornada;
    @FXML
    private RadioButton rbCongreso;
    @FXML
    private CheckBox cbNecesitaHabitaciones;
    @FXML
    private TextField tfCuantas;
    @FXML
    private DatePicker dpFechaEvento;
    @FXML
    private TextField tfNumeroDias;
    @FXML
    private Label lbTipoEventoRes;
    @FXML
    private ToggleGroup tipoEvento;
    @FXML
    private Label lbTipoCocina;
    @FXML
    private Label lbCuantas;
    @FXML
    private Label lbNumeroDias;
    @FXML
    private ImageView ivImagen;
    @FXML
    private Label lbTipoEventoRes2;
    @FXML
    private Button btnLimpiar;
    @FXML
    private Button btnAceptar;
    @FXML
    private Button btnCancelar;
    @FXML
    private Temporizador temporizador;

    private Tooltip tt;

    //Creamos EntityManager y EntityManagerFactory
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("AppHotelPU");
    EntityManager em = emf.createEntityManager();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Añadimos tooltips
        tt = new Tooltip("Introduce DNI");
        tfDNI.setTooltip(tt);
        tt = new Tooltip("Introduce nombre completo");
        tfNombre.setTooltip(tt);
        tt = new Tooltip("Introduce dirección");
        tfDireccion.setTooltip(tt);
        tt = new Tooltip("Introduce telefono");
        tfTelefono.setTooltip(tt);
        tt = new Tooltip("Incluye salón y tipo cocina a elegir");
        rbBanquete.setTooltip(tt);
        tt = new Tooltip("Incluye salón");
        rbJornada.setTooltip(tt);
        tt = new Tooltip("Incluye salón y habitaciones");
        rbCongreso.setTooltip(tt);
        tt = new Tooltip("Número de personas para el evento");
        tfNumeroPersonas.setTooltip(tt);
        tt = new Tooltip("Tipo de cocina");
        cbTipoCocina.setTooltip(tt);
        tt = new Tooltip("Número de habitaciones que necesita");
        tfCuantas.setTooltip(tt);
        tt = new Tooltip("Número de días de la reserva de habitaciones");
        tfNumeroDias.setTooltip(tt);
        tt = new Tooltip("¿Qué día es el evento?");
        dpFechaEvento.setTooltip(tt);

        // Iniciamos el temporizador
        temporizador.setTiempo(60);
        temporizador.disminuyeTiempo();
        temporizador.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                btnAceptar.setDisable(true);
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Pulse limpiar o cancelar.");
                alert.setHeaderText("Sesion caducada.");
                alert.show();
            }
        });

        // Inicializar los campos tipo fecha
        dpFechaEvento.setValue(LocalDate.now().plusDays(1));

        //Añadimos el contenido del ComboBox
        cbTipoCocina.getItems().addAll("Bufé No Vegetariano", "Bufé Vegetariano", "Carta", "Pedir cita con el Chef", "No precisa");

        //Desactivamos todos los campos (respecto al cliente) inicialmente, excepto DNI
        tfNombre.setDisable(true);
        tfDireccion.setDisable(true);
        tfTelefono.setDisable(true);

        //Desactivamos las siguientes opciones, ya que por defecto está inicialmente seleccionado Banquete
        cbNecesitaHabitaciones.setDisable(true);
        lbCuantas.setDisable(true);
        tfCuantas.setDisable(true);
        lbNumeroDias.setDisable(true);
        tfNumeroDias.setDisable(true);

        //Evento para controlar el focus en el tfDNI
        tfDNI.focusedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> arg0, Boolean oldValue, Boolean newValue) {
                //Se hace una instancia de la clase Cliente que buscará en la base de datos si se encuentra el DNI que hemos introducido
                Cliente clienteReserva = em.find(Cliente.class, tfDNI.getText());
                //En caso de que se pierda el focus del tfDNI
                if (!newValue) {
                    //Si se ha encontrado el DNI en la base de datos
                    if (clienteReserva != null) {
                        //Introducimos los valores de texto y desactivamos las casillas
                        tfNombre.setText(clienteReserva.getNombre());
                        tfNombre.setDisable(true);
                        tfDireccion.setText(clienteReserva.getDireccion());
                        tfDireccion.setDisable(true);
                        tfTelefono.setDisable(false);
                        tfTelefono.setText("");
                        tfTelefono.requestFocus();

                        //En caso de que el cliente tenga un teléfono asignado (si no podría editarse)
                        if (clienteReserva.getTelefono() != null) {
                            tfTelefono.setText(clienteReserva.getTelefono());
                            tfTelefono.setDisable(true);

                        }
                    } //En caso de que se borre el DNI
                    else if (tfDNI.getText().equals("")) {
                        //Introducimos los valores de texto y desactivamos las casillas
                        tfNombre.setDisable(true);
                        tfDireccion.setDisable(true);
                        tfTelefono.setDisable(true);
                        tfTelefono.setText("");
                        limpiar();
                    }//En caso de que no se encuentre el DNI, se tiene en cuenta por si previamente se han desactivado
                    else {
                        tfNombre.setDisable(false);
                        //Obtiene el textField del nombre el focus
                        tfNombre.requestFocus();
                        tfDireccion.setDisable(false);
                        tfTelefono.setDisable(false);
                        //Se vuelven los campos vacios
                        tfNombre.setText("");
                        tfDireccion.setText("");
                        tfTelefono.setText("");

                    }
                }
            }
        });

        //Evento que controla el focus en el radioButton Banquete, al cambiarlo mediante teclado
        rbBanquete.focusedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> arg0, Boolean oldValue, Boolean newValue) {
                //Si obtiene el foco
                if (newValue) {
                    onActionEventBanquete(new ActionEvent());
                }
            }
        });

        //Evento que controla el focus en el radioButton Congreso, al cambiarlo mediante teclado
        rbCongreso.focusedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> arg0, Boolean oldValue, Boolean newValue) {
                //Si obtiene el foco
                if (newValue) {
                    onActionEventCongreso(new ActionEvent());
                }
            }
        });

        //Evento que controla el focus en el radioButton Jornada, al cambiarlo mediante teclado
        rbJornada.focusedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> arg0, Boolean oldValue, Boolean newValue) {
                //Si obtiene el foco
                if (newValue) {
                    onActionEventJornada(new ActionEvent());
                }
            }
        });

        btnLimpiar.focusedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> arg0, Boolean oldValue, Boolean newValue) {
                if (newValue) {
                    btnLimpiar.setStyle("-fx-background-color: #5f3110;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");

                } else {
                    btnLimpiar.setStyle("-fx-background-color: #d1a382;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold");
                }
            }
        });

        btnAceptar.focusedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> arg0, Boolean oldValue, Boolean newValue) {
                if (newValue) {
                    btnAceptar.setStyle("-fx-background-color: #5f3110;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");

                } else {
                    btnAceptar.setStyle("-fx-background-color: #d1a382;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold");
                }
            }
        });

        btnCancelar.focusedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> arg0, Boolean oldValue, Boolean newValue) {
                if (newValue) {
                    btnCancelar.setStyle("-fx-background-color: #5f3110;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");

                } else {
                    btnCancelar.setStyle("-fx-background-color: #d1a382;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold");
                }
            }
        });

    }

    @FXML
    private void onActionEventLimpiar(ActionEvent event) {
        //Paramos el temporizador actual
        temporizador.stopTime();

        // Inicializamos un temporizador nuevo
        temporizador.setTiempo(60);
        temporizador.disminuyeTiempo();
        temporizador.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                btnAceptar.setDisable(true);
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Pulse limpiar o cancelar.");
                alert.setHeaderText("Sesion caducada.");
                alert.show();
            }

        });

        // Habilitamos el boton aceptar
        btnAceptar.setDisable(false);

        //Llamamos al método limpiar
        limpiar();
    }

    @FXML
    private void onActionEventCancelar(ActionEvent event) {
        // Buscamos la stage a cerrar y la cerramos
        Stage stage = (Stage) btnCancelar.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void onActionEventAceptar(ActionEvent event) {
        // Pausamos el temporizador
        temporizador.pausar();

        // Variable encargada de comprobar si hay un error
        boolean errorFormato = false;
        boolean mensaje = false;

        // Creamos un objeto cliente y un objeto ReservasSalon que serán guardados en la base de datos
        Cliente nuevoCliente = new Cliente();
        ReservasSalon nuevaReserva = new ReservasSalon();

        // Almacenamos los datos del cliente
        //DNI
        if (!tfDNI.getText().equals("")) {
            nuevoCliente.setDni(tfDNI.getText());
        } else if (tfDNI.getText().equals("") && mensaje == false) {

            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Debe rellenar el DNI del cliente.");
            alert.showAndWait();
            errorFormato = true;
            mensaje = true;
            tfDNI.requestFocus();

            // Reanudamos el temporizador
            temporizador.reanudar();
        }
        //Nombre
        if (!contieneSoloLetras(tfNombre.getText())) {

            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Nombre del cliente no válido.");
            alert.showAndWait();
            errorFormato = true;
            mensaje = true;
            tfNombre.requestFocus();
            // Reanudamos el temporizador
            temporizador.reanudar();
        }

        //Comprobamos que el campo nombre no esté vacio
        if (!tfNombre.getText().equals("")) {
            nuevoCliente.setNombre(tfNombre.getText());
        } else if (tfNombre.getText().equals("") && mensaje == false) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Debe rellenar el nombre del cliente.");
            alert.showAndWait();
            errorFormato = true;
            mensaje = true;
            tfNombre.requestFocus();
            // Reanudamos el temporizador
            temporizador.reanudar();
        }

        // Dirección
        if (!tfDireccion.getText().equals("")) {
            nuevoCliente.setDireccion(tfDireccion.getText());
        } else if (tfDireccion.getText().equals("") && mensaje == false) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Debe rellenar la dirección del cliente.");

            alert.showAndWait();
            errorFormato = true;
            mensaje = true;
            tfDireccion.requestFocus();
            // Reanudamos el temporizador
            temporizador.reanudar();
        }

        //Teléfono
        try {
            Alert alert2;

            if (tfTelefono.getText().length() != 0) {
                Integer.parseInt(tfTelefono.getText());
                nuevoCliente.setTelefono(tfTelefono.getText());
            } else if (tfTelefono.getText().length() != 9 && mensaje == false) {
                alert2 = new Alert(Alert.AlertType.INFORMATION, "El número de teléfono debe tener 9 dígitos.");
                alert2.showAndWait();
                errorFormato = true;
                mensaje = true;
                tfTelefono.requestFocus();
                // Reanudamos el temporizador
                temporizador.reanudar();
            }
        } catch (NumberFormatException ex) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Teléfono con caracteres no numéricos.");
            alert.showAndWait();
            tfTelefono.requestFocus();
            errorFormato = true;
            mensaje = true;
            // Reanudamos el temporizador
            temporizador.reanudar();
        }

        // Provincia
        nuevoCliente.setCodProvincia(new Provincia("XX", "Default"));

        // Almacenamos los datos de la reserva
        if (!tfDNI.getText().equals("")) {
            nuevaReserva.setCliente(tfDNI.getText());
        }

        // Tipo evento
        String eventoSeleccionado;
        if (tipoEvento.getSelectedToggle() == rbBanquete) {
            nuevaReserva.setTipo('B');
            eventoSeleccionado = "Banquete";
        } else if (tipoEvento.getSelectedToggle() == rbJornada) {
            nuevaReserva.setTipo('J');
            eventoSeleccionado = "Jornada";
        } else {
            nuevaReserva.setTipo('C');
            eventoSeleccionado = "Congreso";
        }

        // Número de personas
        if (mensaje == false) {
            try {
                if (tfNumeroPersonas.getText() != "") {
                    Integer npersonas = Integer.parseInt(tfNumeroPersonas.getText());
                    if (npersonas > 0 && npersonas <= 100 && nuevaReserva.getTipo() == 'B') {
                        nuevaReserva.setNumPersonas(Integer.parseInt(tfNumeroPersonas.getText()));
                    } else if (npersonas > 0 && npersonas <= 50 && (nuevaReserva.getTipo() == 'C' || nuevaReserva.getTipo() == 'J')) {
                        nuevaReserva.setNumPersonas(Integer.parseInt(tfNumeroPersonas.getText()));
                    } else if (!(npersonas > 0 && npersonas <= 100) && nuevaReserva.getTipo() == 'B' && mensaje == false) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION, "Número de personas no válido para este tipo de reserva");
                        alert.showAndWait();
                        tfNumeroPersonas.requestFocus();
                        errorFormato = true;
                        mensaje = true;
                        // Reanudamos el temporizador
                        temporizador.reanudar();
                    } else if (!(npersonas > 0 && npersonas <= 50) && (nuevaReserva.getTipo() == 'C' || nuevaReserva.getTipo() == 'J') && mensaje == false) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION, "Número de personas no válido para este tipo de reserva");
                        alert.showAndWait();
                        tfNumeroPersonas.requestFocus();
                        errorFormato = true;
                        mensaje = true;
                        // Reanudamos el temporizador
                        temporizador.reanudar();
                    }
                }

            } catch (NumberFormatException ex) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Número de personas no válido");
                alert.showAndWait();
                tfNumeroPersonas.requestFocus();
                errorFormato = true;
                mensaje = true;
                // Reanudamos el temporizador
                temporizador.reanudar();
            }
        }

        //Tipo cocina
        if (mensaje == false) {
            if (nuevaReserva.getTipo() == 'B' && cbTipoCocina.getValue() != null) {
                nuevaReserva.setTipoCocina(cbTipoCocina.getValue());
            } else if (nuevaReserva.getTipo() == 'B' && cbTipoCocina.getValue() == null) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Tipo de cocina obligatorio");
                alert.showAndWait();
                cbTipoCocina.requestFocus();
                errorFormato = true;
                mensaje = true;
                // Reanudamos el temporizador
                temporizador.reanudar();
            }
        }

        // Tipo de reserva congreso
        if (mensaje == false) {
            if (nuevaReserva.getTipo() == 'C') {
                nuevaReserva.setHabitaciones(cbNecesitaHabitaciones.isSelected());

                if (nuevaReserva.getHabitaciones() == true) {
                    try {
                        if (tfCuantas.getText() != "") {
                            nuevaReserva.setCantHabitaciones(Integer.parseInt(tfCuantas.getText()));
                        } else if (tfCuantas.getText() == "" && mensaje == false) {
                            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Numero Habitaciones vacío");
                            alert.showAndWait();
                            tfCuantas.requestFocus();
                            errorFormato = true;
                            mensaje = true;
                            // Reanudamos el temporizador
                            temporizador.reanudar();
                        }
                    } catch (NumberFormatException ex) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION, "Número de habitaciones no válido");
                        alert.showAndWait();
                        tfCuantas.requestFocus();
                        errorFormato = true;
                        mensaje = true;
                        // Reanudamos el temporizador
                        temporizador.reanudar();
                    }
                }

                //Número de dias
                if (mensaje == false) {
                    try {
                        if (tfNumeroDias.getText() != "") {
                            nuevaReserva.setDiasHabitaciones(Integer.parseInt(tfNumeroDias.getText()));
                        } else if (tfNumeroDias.getText() == "" && mensaje == false) {
                            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Numero de días vacío");
                            alert.showAndWait();
                            tfNumeroDias.requestFocus();
                            errorFormato = true;
                            mensaje = true;
                            // Reanudamos el temporizador
                            temporizador.reanudar();
                        }
                    } catch (NumberFormatException ex) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION, "Número de dias no válido");
                        alert.showAndWait();
                        tfNumeroDias.requestFocus();
                        errorFormato = true;
                        mensaje = true;
                        // Reanudamos el temporizador
                        temporizador.reanudar();
                    }
                }
            }
        }
        // Fecha
        if (mensaje == false) {
            if (dpFechaEvento.getValue() != null) {
                LocalDate localDate = dpFechaEvento.getValue();
                ZonedDateTime zonedDateTime = localDate.atStartOfDay(ZoneId.systemDefault());
                Instant instant = zonedDateTime.toInstant();
                Date date = Date.from(instant);

                LocalDate localDate2 = LocalDate.now();
                ZonedDateTime zonedDateTime2 = localDate2.atStartOfDay(ZoneId.systemDefault());
                Instant instant2 = zonedDateTime2.toInstant();
                Date date2 = Date.from(instant2);

                if (!date.before(date2)) {
                    nuevaReserva.setFecha(date);
                } else if (date.before(date2)) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION, "Fecha anterior a la actual.");
                    alert.showAndWait();
                    dpFechaEvento.requestFocus();
                    errorFormato = true;
                    mensaje = true;
                    // Reanudamos el temporizador
                    temporizador.reanudar();
                }

            } else if (dpFechaEvento.getValue() == null && mensaje == false) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Fecha vacia.");
                alert.showAndWait();
                dpFechaEvento.requestFocus();
                errorFormato = true;
                mensaje = true;
                // Reanudamos el temporizador
                temporizador.reanudar();
            }
        }

        String needHabSeleccionado, cantHabitaciones;
        if (cbNecesitaHabitaciones.isSelected()) {
            needHabSeleccionado = "Sí";
            cantHabitaciones = tfCuantas.getText();
        } else {
            needHabSeleccionado = "No";
            cantHabitaciones = "---";
        }

        // Si no ha habido error, se crea el mensaje de confirmación
        if (mensaje == false) {

            // Crear la alerta de confirmación
            Alert alertConfirmar = new Alert(Alert.AlertType.CONFIRMATION);
            alertConfirmar.setHeaderText(null);
            alertConfirmar.setTitle("Confirmar reserva");

            if (tipoEvento.getSelectedToggle() == rbBanquete) {
                alertConfirmar.setContentText("¿Estas seguro de confirmar la reserva? \n\n"
                        + "DNI: " + tfDNI.getText() + "\n"
                        + "Nombre: " + tfNombre.getText() + "\n"
                        + "Dirección: " + tfDireccion.getText() + "\n"
                        + "Teléfono: " + tfTelefono.getText() + "\n"
                        + "Tipo de evento: " + eventoSeleccionado + "\n"
                        + "Número de personas: " + tfNumeroPersonas.getText() + "\n"
                        + "Tipo de cocina: " + cbTipoCocina.getValue() + "\n"
                        + "Fecha del evento: " + dpFechaEvento.getValue().toString());
            } else if (tipoEvento.getSelectedToggle() == rbJornada) {
                alertConfirmar.setContentText("¿Estas seguro de confirmar la reserva? \n\n"
                        + "DNI: " + tfDNI.getText() + "\n"
                        + "Nombre: " + tfNombre.getText() + "\n"
                        + "Dirección: " + tfDireccion.getText() + "\n"
                        + "Teléfono: " + tfTelefono.getText() + "\n"
                        + "Tipo de evento: " + eventoSeleccionado + "\n"
                        + "Número de personas: " + tfNumeroPersonas.getText() + "\n"
                        + "Fecha del evento: " + dpFechaEvento.getValue().toString());
            } else {
                alertConfirmar.setContentText("¿Estas seguro de confirmar la reserva? \n\n"
                        + "DNI: " + tfDNI.getText() + "\n"
                        + "Nombre: " + tfNombre.getText() + "\n"
                        + "Dirección: " + tfDireccion.getText() + "\n"
                        + "Teléfono: " + tfTelefono.getText() + "\n"
                        + "Tipo de evento: " + eventoSeleccionado + "\n"
                        + "Número de personas: " + tfNumeroPersonas.getText() + "\n"
                        + "Necesita habitación: " + needHabSeleccionado + "\n"
                        + "Cantidad de habitaciones: " + cantHabitaciones + "\n"
                        + "Número de días: " + tfNumeroDias.getText() + "\n"
                        + "Fecha del evento: " + dpFechaEvento.getValue().toString());
            }

            Optional<ButtonType> action = alertConfirmar.showAndWait();
            // Reanudamos el temporizador
            temporizador.reanudar();

            if (action.get() == ButtonType.OK) {
                // Si se acepta la confirmación

                // Comprobamos si el cliente ya existe
                Cliente encontrado = null;

                if (!errorFormato) {
                    encontrado = em.find(Cliente.class, tfDNI.getText());
                }

                if (encontrado != null && !errorFormato) {
                    nuevoCliente.setLocalidad(encontrado.getLocalidad());
                    nuevoCliente.setCodProvincia(encontrado.getCodProvincia());

                    em.getTransaction().begin();
                    // Si lo ha encontrado, lo actualizamos
                    em.merge(nuevoCliente);

                    // Y creamos la reserva
                    em.persist(nuevaReserva);
                    em.getTransaction().commit();

                    //Paramos el temporizador actual
                    temporizador.stopTime();

                    //Mostramos alerta de éxito
                    Alert alert = new Alert(Alert.AlertType.INFORMATION, "Guardado con éxito.");
                    alert.showAndWait();
                    mensaje = true;

                    // Inicializamos un temporizador nuevo
                    temporizador.setTiempo(60);
                    temporizador.disminuyeTiempo();
                    temporizador.setOnAction(new EventHandler<ActionEvent>() {
                        @Override
                        public void handle(ActionEvent event) {
                            btnAceptar.setDisable(true);
                            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Pulse limpiar o cancelar.");
                            alert.setHeaderText("Sesion caducada.");
                            alert.show();
                        }

                    });

                    //Llamamos al método limpiar
                    limpiar();
                } else if (encontrado == null && errorFormato == false && mensaje == false) {
                    // Si no lo ha encontrado, creamos uno nuevo
                    em.getTransaction().begin();
                    em.persist(nuevoCliente);

                    // Creamos la reserva
                    em.persist(nuevaReserva);
                    em.getTransaction().commit();

                    //Paramos el temporizador actual
                    temporizador.stopTime();

                    //Mostramos alerta de éxito
                    Alert alert = new Alert(Alert.AlertType.INFORMATION, "Guardado con éxito.");
                    alert.showAndWait();
                    mensaje = true;

                    // Inicializamos un temporizador nuevo
                    temporizador.setTiempo(60);
                    temporizador.disminuyeTiempo();
                    temporizador.setOnAction(new EventHandler<ActionEvent>() {
                        @Override
                        public void handle(ActionEvent event) {
                            btnAceptar.setDisable(true);
                            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Pulse limpiar o cancelar.");
                            alert.setHeaderText("Sesion caducada.");
                            alert.show();
                        }

                    });

                    //Llamamos al método limpiar
                    limpiar();
                }
            }
        }
    }

    @FXML
    private void onActionEventBanquete(ActionEvent event) {
        //Desactivamos aquellos que no queremos que se usen
        cbNecesitaHabitaciones.setDisable(true);
        cbNecesitaHabitaciones.setSelected(false);
        lbCuantas.setDisable(true);
        tfCuantas.setDisable(true);
        lbNumeroDias.setDisable(true);
        tfNumeroDias.setDisable(true);

        //Quitamos aquellos valores relativos a otro tipo de evento
        tfCuantas.setText("");
        tfNumeroDias.setText("");

        //Activamos los que queremos que se usen
        lbTipoCocina.setDisable(false);
        cbTipoCocina.setDisable(false);

        //Cambiamos el contenido de la label de resultado (tipo)
        lbTipoEventoRes.setText("Tipo: Banquete");
        lbTipoEventoRes.setStyle("-fx-text-fill: #028BB1");
        lbTipoEventoRes2.setStyle("-fx-text-fill: #028BB1;-fx-font-style: italic");

        //Cambiamos la imagen
        ivImagen.setImage(new Image(getClass().getResourceAsStream("/Resources/images/Banquete.jpg")));

    }

    @FXML
    private void onActionEventJornada(ActionEvent event) {
        //Desactivamos aquellos que no queremos que se usen
        cbNecesitaHabitaciones.setDisable(true);
        cbNecesitaHabitaciones.setSelected(false);
        lbCuantas.setDisable(true);
        tfCuantas.setDisable(true);
        lbNumeroDias.setDisable(true);
        tfNumeroDias.setDisable(true);
        lbTipoCocina.setDisable(true);
        cbTipoCocina.setDisable(true);

        //Quitamos aquellos valores relativos a otro tipo de evento
        cbTipoCocina.setValue(null);
        tfCuantas.setText("");
        tfNumeroDias.setText("");

        //Cambiamos el contenido de la label de resultado (tipo)
        lbTipoEventoRes.setText("Tipo: Jornada");
        lbTipoEventoRes.setStyle("-fx-text-fill: #9702B1");
        lbTipoEventoRes2.setStyle("-fx-text-fill: #9702B1;-fx-font-style: italic");

        //Cambiamos la imagen
        ivImagen.setImage(new Image(getClass().getResourceAsStream("/Resources/images/Jornada.jpg")));
    }

    @FXML
    private void onActionEventCongreso(ActionEvent event) {
        //Desactivamos aquellos que no queremos que se usen
        lbTipoCocina.setDisable(true);
        cbTipoCocina.setDisable(true);

        //Quitamos aquellos valores relativos a otro tipo de evento
        cbTipoCocina.setValue(null);

        //Activamos los que queremos que se usen
        cbNecesitaHabitaciones.setDisable(false);
        lbNumeroDias.setDisable(false);
        tfNumeroDias.setDisable(false);

        //Cambiamos el contenido de la label de resultado (tipo)
        lbTipoEventoRes.setText("Tipo: Congreso");
        lbTipoEventoRes.setStyle("-fx-text-fill: #B16E02");
        lbTipoEventoRes2.setStyle("-fx-text-fill: #B16E02;-fx-font-style: italic");

        //Cambiamos la imagen
        ivImagen.setImage(new Image(getClass().getResourceAsStream("/Resources/images/Congreso.jpg")));
    }

    @FXML
    private void onActionNecesitaHabitaciones(ActionEvent event) {
        if (cbNecesitaHabitaciones.isSelected()) {
            lbCuantas.setDisable(false);
            tfCuantas.setDisable(false);
        } else {
            lbCuantas.setDisable(true);
            tfCuantas.setDisable(true);
        }
    }

    //Método limpiar
    private void limpiar() {
        // Resetear los campos del cliente
        tfDNI.setText("");
        tfNombre.setText("");
        tfDireccion.setText("");
        tfTelefono.setText("");

        // Resetear los datos de la reserva
        tipoEvento.selectToggle(rbBanquete);
        tfNumeroPersonas.setText("");
        cbTipoCocina.setValue(null);
        cbTipoCocina.setDisable(false);
        lbTipoCocina.setDisable(false);
        cbNecesitaHabitaciones.setSelected(false);
        tfCuantas.setText("");
        dpFechaEvento.setValue(LocalDate.now().plusDays(1));
        tfNumeroDias.setText("");

        //Campos cliente y reserva deshabilitados
        tfNombre.setDisable(true);
        tfDireccion.setDisable(true);
        tfTelefono.setDisable(true);
        cbNecesitaHabitaciones.setDisable(true);
        lbCuantas.setDisable(true);
        tfCuantas.setDisable(true);
        lbNumeroDias.setDisable(true);
        tfNumeroDias.setDisable(true);
    }

    //Método para comprobar que se han introducido solo letras
    public boolean contieneSoloLetras(String cadena) {
        for (int i = 0; i < cadena.length(); i++) {
            char c = cadena.charAt(i);
            // Si no está entre a y z, ni entre A y Z, ni es un espacio
            if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == ' ') && c != 'á' && c != 'é' && c != 'í' && c != 'ó' && c != 'ú' && c != 'ü') {
                return false;
            }
        }
        return true;
    }

    //Estilos de botones
    //Boton Limpiar
    @FXML
    private void onMouseExitLimpiar(MouseEvent event) {
        btnLimpiar.setStyle("-fx-background-color: #d1a382;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold");
    }

    @FXML
    private void onMouseEnterLimpiar(MouseEvent event) {
        btnLimpiar.setStyle("-fx-background-color: #5f3110;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");
    }

    @FXML
    private void onMouseReleaseLimpiar(MouseEvent event) {
        btnLimpiar.setStyle("-fx-background-color: #5f3110;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");

    }

    @FXML
    private void onMousePressLimpiar(MouseEvent event) {
        btnLimpiar.setStyle("-fx-background-color: #351B09;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");

    }

    //Boton Aceptar
    @FXML
    private void onMouseExitAceptar(MouseEvent event) {
        btnAceptar.setStyle("-fx-background-color: #d1a382;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold");
    }

    @FXML
    private void onMouseEnterAceptar(MouseEvent event) {
        btnAceptar.setStyle("-fx-background-color: #5f3110;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");
    }

    @FXML
    private void onMousePressAceptar(MouseEvent event) {
        btnAceptar.setStyle("-fx-background-color: #5f3110;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");

    }

    @FXML
    private void onMouseReleaseAceptar(MouseEvent event) {
        btnAceptar.setStyle("-fx-background-color: #351B09;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");

    }

    //Boton Cancelar
    @FXML
    private void onMouseExitCancelar(MouseEvent event) {
        btnCancelar.setStyle("-fx-background-color: #d1a382;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold");
    }

    @FXML
    private void onMouseEnterCancelar(MouseEvent event) {
        btnCancelar.setStyle("-fx-background-color: #5f3110;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");
    }

    @FXML
    private void onMousePressCancelar(MouseEvent event) {
        btnCancelar.setStyle("-fx-background-color: #5f3110;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");

    }

    @FXML
    private void onMouseReleaseCancelar(MouseEvent event) {
        btnCancelar.setStyle("-fx-background-color: #351B09;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");

    }

    @FXML
    private void onIntroPressedLimpiar(KeyEvent event) {
        if (event.getCode().equals(KeyCode.ENTER)) {
            limpiar();
        }
    }

    @FXML
    private void onIntroPressedAceptar(KeyEvent event) {
        if (event.getCode().equals(KeyCode.ENTER)) {
            onActionEventAceptar(new ActionEvent());
        }
    }

    @FXML
    private void onIntroPressedCancelar(KeyEvent event) {
        if (event.getCode().equals(KeyCode.ENTER)) {
            onActionEventCancelar(new ActionEvent());
        }
    }

}
