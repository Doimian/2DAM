package apphotel;

import data.entities.Cliente;
import data.entities.Provincia;
import data.entities.ReservasHab;
import java.net.URL;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.control.Tooltip;
import javafx.stage.Stage;
import javafx.scene.input.MouseEvent;
import javafx.util.StringConverter;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;


/*
*    @author Equipo Bionic
*
 */
public class Habitaciones implements Initializable {

    //Creamos EntityManagerFactory y EntityManager
    private Cliente cliente;
    private EntityManager entityManager;
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("AppHotelPU");
    EntityManager em = emf.createEntityManager();

    //Inicializamos los elementos FXML
    @FXML
    private TextField fxtfDni;
    @FXML
    private TextField fxtfNombre;
    @FXML
    private TextField fxtfDireccion;
    @FXML
    private TextField fxtfLocalidad;
    @FXML
    private ToggleGroup regimen;
    @FXML
    private ComboBox<Provincia> fxcbProvincia;
    @FXML
    private ComboBox fxcbNumHab;
    @FXML
    private ComboBox fxcbTipoHabitacion;
    @FXML
    private DatePicker fxdateLlegada;
    @FXML
    private DatePicker fxdateSalida;
    @FXML
    private RadioButton fxrbAlojamiento;
    @FXML
    private CheckBox fxcbFumador;
    @FXML
    private Button btnLimpiar;
    @FXML
    private Button btnAceptar;
    @FXML
    private Button btnCancelar;
    @FXML
    private RadioButton fxrbMediaPension;
    @FXML
    private RadioButton fxrbPensionCompleta;
    private Tooltip tt;

    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        
// Añadimos tooltips
        tt = new Tooltip("Introduce dni");
        fxtfDni.setTooltip(tt);
        tt = new Tooltip("Introduce nombre completo");
        fxtfNombre.setTooltip(tt);
        tt = new Tooltip("Introduce direccion");
        fxtfDireccion.setTooltip(tt);
        tt = new Tooltip("Introduce localidad");
        fxtfLocalidad.setTooltip(tt);
        tt = new Tooltip("Elige provincia");
        fxcbProvincia.setTooltip(tt);
        tt = new Tooltip("Introduzce una fecha de llegada al hotel");
        fxdateLlegada.setTooltip(tt);
        tt = new Tooltip("Introduzce una fecha de salida del hotel");
        fxdateSalida.setTooltip(tt);
        tt = new Tooltip("Introduzce el numero de habitaciones que necesitas");
        fxcbNumHab.setTooltip(tt);
        tt = new Tooltip("Introduzce el tipo de habitaciones que necesitas");
        fxcbTipoHabitacion.setTooltip(tt);
        tt = new Tooltip("¿Eres fumador/a?");
        fxcbFumador.setTooltip(tt);
        tt = new Tooltip("Incluirá alojamiento y desayuno");
        fxrbAlojamiento.setTooltip(tt);
        tt = new Tooltip("Incluirá alojamiento, desayuno y almuerzo");
        fxrbMediaPension.setTooltip(tt);
        tt = new Tooltip("Incluirá alojamiento, desayuno, almuerzo y cena");
        fxrbPensionCompleta.setTooltip(tt);
        
        // Inicializar los campos tipo fecha
        fxdateLlegada.setValue(LocalDate.now());
        fxdateSalida.setValue(LocalDate.now().plusDays(1));
        
        //Añadimos contenido a los ComboBox
        fxcbNumHab.getItems().addAll("1", "2", "3", "4", "5", "6", "7", "8", "9", "10");
        fxcbTipoHabitacion.getItems().addAll("Simple", "Doble uso individual", "Doble con cama compartida", "Triple", "Quad");

        //Desactivamos todos los campos (respecto al cliente) inicialmente, excepto DNI
        fxtfNombre.setDisable(true);
        fxtfDireccion.setDisable(true);
        fxtfLocalidad.setDisable(true);
        fxcbProvincia.setDisable(true);

        //Evento para controlar el focus en el tfDNI
        fxtfDni.focusedProperty().addListener(new ChangeListener<Boolean>() {

            @Override
            public void changed(ObservableValue<? extends Boolean> arg0, Boolean oldValue, Boolean newValue) {
                //Hacemos una instancia de la clase Cliente que buscará en la base de datos si se encuentra el DNI que hemos introducido
                Cliente clienteReserva = em.find(Cliente.class, fxtfDni.getText());
                //En caso de que se pierda el focus del tfDNI
                if (!newValue) {
                    //Si se ha encontrado el DNI en la base de datos
                    if (clienteReserva != null) {
                        //Introducimos los valores de texto y desactivamos las casillas
                        fxtfNombre.setText(clienteReserva.getNombre());
                        fxtfNombre.setDisable(true);
                        fxtfDireccion.setText(clienteReserva.getDireccion());
                        fxtfDireccion.setDisable(true);
                        fxtfLocalidad.setText("");
                        fxtfLocalidad.setDisable(false);
                        fxtfLocalidad.requestFocus();
                        fxcbProvincia.setPromptText("");
                        fxcbProvincia.setDisable(false);

                        //En caso de que el cliente tenga una localidad asignada (si no podría editarse)
                        if (clienteReserva.getLocalidad() != null) {
                            fxtfLocalidad.setText(clienteReserva.getLocalidad());
                            fxtfLocalidad.setDisable(true);
                            fxtfLocalidad.requestFocus();

                        }
                        //En caso de que el cliente tenga una provincia asignada (si no podría editarse)
                        if (!clienteReserva.getCodProvincia().getCodigo().equals("XX")) {
                            fxcbProvincia.setDisable(true);
                            fxcbProvincia.setPromptText(clienteReserva.getCodProvincia().getCodigo() + "-" + clienteReserva.getCodProvincia().getNombre());
                        }
                    } //En caso de que se borre el DNI
                    else if (fxtfDni.getText().equals("")) {
                        //Introducimos los valores de texto y desactivamos las casillas
                        fxtfNombre.setDisable(true);
                        fxtfDireccion.setDisable(true);
                        fxtfLocalidad.setDisable(true);
                        fxcbProvincia.setDisable(true);
                        limpiar();
                    } //En caso de que no se encuentre el DNI, se tiene en cuenta por si previamente se han desactivado
                    else {
                        fxtfNombre.setDisable(false);
                        fxtfDireccion.setDisable(false);
                        fxtfLocalidad.setDisable(false);
                        fxcbProvincia.setDisable(false);
                        fxtfNombre.requestFocus();
                        //Se vuelven los campos vacios
                        fxtfNombre.setText("");
                        fxtfDireccion.setText("");
                        fxtfLocalidad.setText("");
                        fxcbProvincia.setPromptText("");
                    }
                }
            }
        });
        //Llamamos al método mostrarProvincias
        mostrarProvincias();
    }

    //Método mostrarProvincias
    public void mostrarProvincias() {
        //Creamos EntityManagerFactory
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("AppHotelPU");
        entityManager = emf.createEntityManager();

        //Buscamos provincias en la base de datos
        Query queryProvinciaFindAll = entityManager.createNamedQuery("Provincia.findAll");
        List listProvincia = queryProvinciaFindAll.getResultList();
        //Quitamos de la lista el primer valor, para que no introduzca el valor XX-Default
        listProvincia.remove(0);
        //Añadimos los items al combobox
        fxcbProvincia.setItems(FXCollections.observableList(listProvincia));
        fxcbProvincia.setCellFactory((ListView<Provincia> l) -> new ListCell<Provincia>() {
            @Override
            protected void updateItem(Provincia provincia, boolean empty) {
                super.updateItem(provincia, empty);
                if (provincia == null || empty || provincia.getCodigo().equals("XX")) {
                    Provincia victima = provincia;
                    fxcbProvincia.getItems().remove(victima);
                } else {
                    setText(provincia.getCodigo() + "-" + provincia.getNombre());
                }
            }
        });

        //
        fxcbProvincia.setConverter(new StringConverter<Provincia>() {
            @Override
            public String toString(Provincia provincia) {
                if (provincia == null) {
                    return "Seleccione provincia:";
                    //return null;
                } else {
                    return provincia.getCodigo() + "-" + provincia.getNombre();
                }
            }

            @Override
            public Provincia fromString(String userId) {
                return null;
            }
        });
    
        btnLimpiar.focusedProperty().addListener(new ChangeListener<Boolean>(){
            @Override
            public void changed(ObservableValue<? extends Boolean> arg0, Boolean oldValue, Boolean newValue) {
                if(newValue)
                {
                    btnLimpiar.setStyle("-fx-background-color: #5f3110;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");

                }
                else
                {
                    btnLimpiar.setStyle("-fx-background-color: #d1a382;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold");
                }
            }
        });
        
        btnAceptar.focusedProperty().addListener(new ChangeListener<Boolean>(){
            @Override
            public void changed(ObservableValue<? extends Boolean> arg0, Boolean oldValue, Boolean newValue) {
                if(newValue)
                {
                    btnAceptar.setStyle("-fx-background-color: #5f3110;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");

                }
                else
                {
                    btnAceptar.setStyle("-fx-background-color: #d1a382;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold");
                }
            }
        });
        
        btnCancelar.focusedProperty().addListener(new ChangeListener<Boolean>(){
            @Override
            public void changed(ObservableValue<? extends Boolean> arg0, Boolean oldValue, Boolean newValue) {
                if(newValue)
                {
                    btnCancelar.setStyle("-fx-background-color: #5f3110;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");

                }
                else
                {
                    btnCancelar.setStyle("-fx-background-color: #d1a382;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold");
                }
            }
        });
    
    }

    @FXML
    private void btnOnActionLimpiar(ActionEvent event) {
        //llamamos al método limpiar
        limpiar();
    }

    @FXML
    private void btnOnActionAceptar(ActionEvent event) {
        // Variable que va a controlar si hay error
        boolean errorFormato = false;
        boolean mensaje = false;

        // Creamos un objeto cliente y un objeto ReservasHab que serán guardados en la base de datos
        Cliente nuevoCliente = new Cliente();
        ReservasHab nuevaReserva = new ReservasHab();

        // Almacenamos los datos del cliente
        //DNI
        if (!fxtfDni.getText().equals("")) {
            nuevoCliente.setDni(fxtfDni.getText());
        } else if (fxtfDni.getText().equals("") && mensaje == false) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Debe rellenar el DNI del cliente.");
            alert.showAndWait();
            fxtfDni.requestFocus();
            errorFormato = true;
            mensaje = true;
        }
        //Nombre
        if (!contieneSoloLetras(fxtfNombre.getText())) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Nombre del cliente no válido.");
            alert.showAndWait();
            fxtfNombre.requestFocus();
            errorFormato = true;
            mensaje = true;
        }

        if (!fxtfNombre.getText().equals("")) {
            nuevoCliente.setNombre(fxtfNombre.getText());
        } else if (fxtfNombre.getText().equals("") && mensaje == false) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Debe rellenar el nombre del cliente.");
            alert.showAndWait();
            fxtfNombre.requestFocus();
            errorFormato = true;
            mensaje = true;
        }

        // Direccion
        if (!fxtfDireccion.getText().equals("")) {
            nuevoCliente.setDireccion(fxtfDireccion.getText());
        } else if (fxtfDireccion.getText().equals("") && mensaje == false) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Debe rellenar la dirección del cliente.");
            alert.showAndWait();
            fxtfDireccion.requestFocus();
            errorFormato = true;
            mensaje = true;
        }

        // Localidad
        if (!contieneSoloLetras(fxtfLocalidad.getText()) && mensaje == false) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Localidad del cliente no válida.");
            alert.showAndWait();
            fxtfLocalidad.requestFocus();
            errorFormato = true;
            mensaje = true;
        }

        if (!fxtfLocalidad.getText().equals("")) {
            nuevoCliente.setLocalidad(fxtfLocalidad.getText());
        } else if (fxtfLocalidad.getText().equals("") && mensaje == false) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Debe rellenar la localidad del cliente.");
            alert.showAndWait();
            fxtfLocalidad.requestFocus();
            errorFormato = true;
            mensaje = true;
        }

        // Provincia
        String codigo;
        if ((fxcbProvincia.getValue() != null || fxcbProvincia.isDisable()) && !errorFormato) {
            if (fxcbProvincia.getValue() != null) {
                codigo = fxcbProvincia.getValue().getCodigo();
                Provincia encontrada = em.find(Provincia.class, codigo);
                nuevoCliente.setCodProvincia(encontrada);
            } else {
                Cliente client = em.find(Cliente.class, nuevoCliente.getDni());
                Provincia encontrada = client.getCodProvincia();
                nuevoCliente.setCodProvincia(encontrada);
            }

        } else if ((fxcbProvincia.getValue() == null || fxcbProvincia.isDisable() == false) && mensaje == false) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Debe rellenar la provincia del cliente.");
            alert.showAndWait();
            fxcbProvincia.requestFocus();
            errorFormato = true;
            mensaje = true;
        }

        //DATOS DE LA RESERVA
        if (!fxtfDni.getText().equals("")) {
            nuevaReserva.setCliente(fxtfDni.getText());
        }

        // Fecha llegada
        if (fxdateLlegada.getValue() != null) {
            LocalDate localDate = fxdateLlegada.getValue();
            ZonedDateTime zonedDateTime = localDate.atStartOfDay(ZoneId.systemDefault());
            Instant instant = zonedDateTime.toInstant();
            Date date = Date.from(instant);

            LocalDate localDate2 = LocalDate.now();
            ZonedDateTime zonedDateTime2 = localDate2.atStartOfDay(ZoneId.systemDefault());
            Instant instant2 = zonedDateTime2.toInstant();
            Date date2 = Date.from(instant2);

            //Contemplamos que la fecha de llegada sea posterior a la actual
            if (!date.before(date2)) 
            {
                nuevaReserva.setFechaInicio(date);
            } else if (date.before(date2) && mensaje == false) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Fecha de llegada anterior a la actual.");
                alert.showAndWait();
                fxdateLlegada.requestFocus();
                errorFormato = true;
                mensaje = true;
            }
        } //Si fecha de llegada está vacía
        else if (fxdateLlegada.getValue() == null && mensaje == false) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Debe rellenar la fecha de llegada.");

            alert.showAndWait();
            fxdateLlegada.requestFocus();
            errorFormato = true;
            mensaje = true;
        }

        // Fecha salida
        if (fxdateSalida.getValue() != null) 
        {
            LocalDate localDate = fxdateSalida.getValue();
            ZonedDateTime zonedDateTime = localDate.atStartOfDay(ZoneId.systemDefault());
            Instant instant = zonedDateTime.toInstant();
            Date date = Date.from(instant);

            LocalDate localDate2 = fxdateLlegada.getValue();
            ZonedDateTime zonedDateTime2 = localDate2.atStartOfDay(ZoneId.systemDefault());
            Instant instant2 = zonedDateTime2.toInstant();
            Date date2 = Date.from(instant2);

            //Contemplamos que la fecha de salida sea posterior a la de llegada
            if (date.after(date2)) 
            {
                nuevaReserva.setFechaFinal(date);

            }
            else if (!date.after(date2) && mensaje == false) 
            {
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Fecha salida anterior o igual a de llegada.");
                alert.showAndWait();
                fxdateSalida.requestFocus();
                errorFormato = true;
                mensaje = true;
            }
        } //Si fecha de salida está vacía
        else if ((fxdateSalida.getValue() == null) && mensaje == false) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Debe rellenar la fecha de salida.");

            alert.showAndWait();
            fxdateSalida.requestFocus();
            errorFormato = true;
            mensaje = true;
        }

        //Número de habitaciones
        if (fxcbNumHab.getValue() != null) {
            try {
                Integer i = Integer.parseInt(fxcbNumHab.getValue().toString());
                nuevaReserva.setCantHab(i);
            } catch (NumberFormatException ex) {
                errorFormato = true;
            }
        } //Si la cantidad de habitaciones está vacía
        else if (fxcbNumHab.getValue() == null && mensaje == false) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Debe insertar la cantidad de habitaciones.");
            alert.showAndWait();
            fxcbNumHab.requestFocus();
            errorFormato = true;
            mensaje = true;
        }

        //Tipo de habitación
        if (fxcbTipoHabitacion.getValue() != null) {
            try {
                String i = fxcbTipoHabitacion.getValue().toString();
                nuevaReserva.setTipo(i);
            } catch (NumberFormatException ex) {
                errorFormato = true;
            }
        } //Si el tipo de habitación está vacío
        else if (fxcbTipoHabitacion.getValue() == null && mensaje == false) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Debe insertar el tipo de habitación.");

            alert.showAndWait();
            fxcbTipoHabitacion.requestFocus();
            errorFormato = true;
            mensaje = true;
        }

        String regimenSeleccionado;
        if (regimen.getSelectedToggle() == fxrbAlojamiento) 
        {
            nuevaReserva.setRegimen("Alojamiento");
            regimenSeleccionado = "Alojamiento y desayuno.";
        } 
        else if (regimen.getSelectedToggle() == fxrbMediaPension) 
        {
            nuevaReserva.setRegimen("Media");
            regimenSeleccionado = "Media pensión.";
        } 
        else 
        {
            nuevaReserva.setRegimen("Completa");
            regimenSeleccionado = "Pensión completa.";
        }

        // Fumador
        nuevaReserva.setFumador(fxcbFumador.isSelected());
        
        String fumadorSelected;
        if(fxcbFumador.isSelected())
            fumadorSelected = "Sí";
        else
            fumadorSelected = "No";
        
        
        
        // Si no ha habido error, se crea el mensaje de confirmación
        if(mensaje == false)
        {
            
            // Crear la alerta de confirmación
            Alert alertConfirmar = new Alert(Alert.AlertType.CONFIRMATION);
            alertConfirmar.setHeaderText(null);
            alertConfirmar.setTitle("Confirmar reserva");
            alertConfirmar.setContentText("¿Estás seguro de confirmar la reserva? \n\n"
                    + "DNI: " + fxtfDni.getText() + "\n"
                    + "Nombre: " + fxtfNombre.getText() + "\n"
                    + "Dirección: " + fxtfDireccion.getText() + "\n"
                    + "Localidad: " + fxtfLocalidad.getText() + "\n"
                    + "Provincia: " + fxcbProvincia.getValue() + "\n"
                    + "Fecha de entrada: " + fxdateLlegada.getValue().toString() + "\n"
                    + "Fecha de salida: " + fxdateSalida.getValue().toString() + "\n"
                    + "Número de habitaciones: " + fxcbNumHab.getValue() + "\n"
                    + "Tipo de habitación: " + fxcbTipoHabitacion.getValue() + "\n"
                    + "Fumador: " + fumadorSelected + "\n"
                    + "Régimen: " + regimenSeleccionado);


            Optional<ButtonType> action = alertConfirmar.showAndWait();


            if (action.get() == ButtonType.OK) 
            {
                // Si se acepta la confirmación
                // Comprobar si el cliente ya existe
                Cliente encontrado = null;

                if(!errorFormato)
                    encontrado = em.find(Cliente.class, fxtfDni.getText());

                if (encontrado != null && !errorFormato) 
                {
                    nuevoCliente.setTelefono(encontrado.getTelefono());

                    em.getTransaction().begin();
                    // Si lo ha encontrado, lo actualizamos
                    em.merge(nuevoCliente);

                    // Y creamos la reserva
                    em.persist(nuevaReserva);
                    em.getTransaction().commit();

                    Alert alert = new Alert(Alert.AlertType.INFORMATION, "Guardado con éxito.");
                    alert.showAndWait();
                    limpiar();
                } 
                else if (encontrado == null && errorFormato == false && mensaje == false) 
                {
                    // Si no lo ha encontrado, creamos uno nuevo
                    em.getTransaction().begin();
                    em.persist(nuevoCliente);
                    // Creamos la reserva
                    em.persist(nuevaReserva);
                    em.getTransaction().commit();
                    Alert alert = new Alert(Alert.AlertType.INFORMATION, "Guardado con éxito.");
                    alert.showAndWait();
                    mensaje = true;
                    limpiar();
                }
            } 
        } 
    }

    @FXML
    private void btnOnActionCancelar(ActionEvent event) {
        // Busca la stage a cerrar y la cerramos
        Stage stage = (Stage) btnCancelar.getScene().getWindow();
        stage.close();
    }

    //Método limpiar
    private void limpiar() {
        // Resetear los campos del cliente
        fxtfDni.setText("");
        fxtfNombre.setText("");
        fxtfDireccion.setText("");
        fxtfLocalidad.setText("");
        fxcbProvincia.setPromptText("");

        // Resetear los campos de la reserva
        fxdateLlegada.setValue(null/*LocalDate.now()*/);
        fxdateSalida.setValue(null/*LocalDate.now()*/);
        fxcbNumHab.setValue("");
        fxcbTipoHabitacion.setValue("");
        fxcbFumador.setSelected(false);
        regimen.selectToggle(fxrbAlojamiento);

        //Campos cliente enable
        fxtfNombre.setDisable(true);
        fxtfDireccion.setDisable(true);
        fxtfLocalidad.setDisable(true);
        fxcbProvincia.setDisable(true);
        fxcbProvincia.setValue(null);
    }

    //Método para comprobar si solo contiene letras o más cosas
    public boolean contieneSoloLetras(String cadena) {
        for (int i = 0; i < cadena.length(); i++) {
            char c = cadena.charAt(i);
            // Si no está entre a y z, ni entre A y Z, ni es un espacio
            if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == ' ') && c != 'á' && c != 'é' && c != 'í' && c != 'ó' && c != 'ú' && c != 'ü') {
                return false;
            }
        }
        return true;
    }

    //Estilos de botones
    //Boton Limpiar
    @FXML
    private void onMouseExitLimpiar(MouseEvent event) {
        btnLimpiar.setStyle("-fx-background-color: #d1a382;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold");
    }

    @FXML
    private void onMouseEnterLimpiar(MouseEvent event) {
        btnLimpiar.setStyle("-fx-background-color: #5f3110;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");
    }

    @FXML
    private void onMouseReleaseLimpiar(MouseEvent event) {
        btnLimpiar.setStyle("-fx-background-color: #5f3110;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");

    }

    @FXML
    private void onMousePressLimpiar(MouseEvent event) {
        btnLimpiar.setStyle("-fx-background-color: #351B09;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");

    }

    //Boton Aceptar
    @FXML
    private void onMouseExitAceptar(MouseEvent event) {
        btnAceptar.setStyle("-fx-background-color: #d1a382;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold");
    }

    @FXML
    private void onMouseEnterAceptar(MouseEvent event) {
        btnAceptar.setStyle("-fx-background-color: #5f3110;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");
    }

    @FXML
    private void onMousePressAceptar(MouseEvent event) {
        btnAceptar.setStyle("-fx-background-color: #5f3110;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");

    }

    @FXML
    private void onMouseReleaseAceptar(MouseEvent event) {
        btnAceptar.setStyle("-fx-background-color: #351B09;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");

    }

    //Boton Cancelar
    @FXML
    private void onMouseExitCancelar(MouseEvent event) {
        btnCancelar.setStyle("-fx-background-color: #d1a382;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold");
    }

    @FXML
    private void onMouseEnterCancelar(MouseEvent event) {
        btnCancelar.setStyle("-fx-background-color: #5f3110;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");
    }

    @FXML
    private void onMousePressCancelar(MouseEvent event) {
        btnCancelar.setStyle("-fx-background-color: #5f3110;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");

    }

    @FXML
    private void onMouseReleaseCancelar(MouseEvent event) {
        btnCancelar.setStyle("-fx-background-color: #351B09;-fx-border-radius:5;-fx-border-color:black; -fx-font-weight: bold;-fx-text-fill: white");

    }

    @FXML
    private void onIntroPressedLimpiar(KeyEvent event) {
        if(event.getCode().equals(KeyCode.ENTER))
        {
            limpiar();
        }
    }

    @FXML
    private void onIntroPressedAceptar(KeyEvent event) {
        if(event.getCode().equals(KeyCode.ENTER))
        {
            btnOnActionAceptar(new ActionEvent());
        }
    }

    @FXML
    private void onIntroPressedCancelar(KeyEvent event) {
        if(event.getCode().equals(KeyCode.ENTER))
        {
            btnOnActionCancelar(new ActionEvent());
        }
    }

}
