#ifndef HLC_STRING_EJ6_H
#define HLC_STRING_EJ6_H


class HLC_String_Ej6
{
    public:
        HLC_String_Ej6();
        virtual ~HLC_String_Ej6();

    protected:

    private:
};

#endif // HLC_STRING_EJ6_H
