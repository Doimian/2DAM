#include "HLC_String_Ej6.h"

HLC_String_Ej6::HLC_String_Ej6()
{
    //ctor
}

HLC_String_Ej6::~HLC_String_Ej6()
{
    //dtor
}
